/***********************************Author Name:Manoj M Maragiri*********Emp Id : 155246******************************************/
/*The AMSException class extends the Exception class and contains a parameterized constructor which takes
 * a String input and passes to the Exception class. 
*/
package com.capgemini.ams.exception;

public class AMSException extends Exception {
	private static final long serialVersionUID = 12121212L;

	public AMSException(String message) {
		super(message);
	}
}