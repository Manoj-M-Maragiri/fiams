/***********************************Author Name:Manoj M Maragiri******Emp Id : 155246******************************************/
/*The IAssetDAOAdmin interface contains the abstract methods of the AssetDAOAdmin 
 * which is called to perform the operations that modification to the database 
 * and retrieve data and display in the AssetClient class
*/
package com.capgemini.ams.dao;

import java.util.ArrayList;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.exception.AMSException;

public interface IAssetDAOAdmin {

	public abstract int addAssetDetails(AssetDetailsBean assetDetails,int status) throws AMSException;
	
	public abstract ArrayList<AssetDetailsBean> assetInInventory() throws AMSException;
	
	public abstract int updateAssetName(AssetDetailsBean assetNameDetails) throws AMSException;
	
	public abstract int updateAssetDescription(AssetDetailsBean assetDescriptionDetails) throws AMSException;
	
	public abstract int updateAssetQuantity(AssetDetailsBean assetQuantityDetails) throws AMSException;
	
	public abstract int updateAssetStatus(int assetId,int newAssetStatus) throws AMSException;
	
	public abstract ArrayList<AssetAllocationBean> displayUnapprovedAssets() throws AMSException;
	
	public abstract int checkAssetAvailability(AssetAllocationBean assetAllocation) throws AMSException;
	
	public abstract int approveRequest(AssetAllocationBean assetAllocation) throws AMSException;
	
	public abstract int rejectRequest(AssetAllocationBean assetAllocation) throws AMSException;

	public abstract ArrayList<AssetAllocationBean> displayAllocatedAssets() throws AMSException;
	
	public abstract ArrayList<AssetAllocationBean> displayUnallocatedAssets() throws AMSException;
	
}
