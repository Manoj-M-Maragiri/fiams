/***********************************Author Name:Manoj M Maragiri******Emp Id : 155246******************************************/
/*The IQueryMapper contains the Queries that are used in this application.
 * The queries used by both Admin and the user are available in this Interface.
 * All the Queries are of String Datatype which are made final and can be used by any class
*/
package com.capgemini.ams.dao;

public interface IQueryMapper {
	//Queries used by Manager method
	//To authenticate the credentials
	public final String AUTHENTICATE_USER="SELECT UserId,UserPassword,UserType FROM User_Master WHERE UserId=?";
	
	//To display the assetDetails to the manager to show the assetId to the user to make a request 
	public final String DISPLAY_ASSET_DETAILS="SELECT AssetId,AssetName,AssetDes FROM Asset ORDER BY AssetId";
	
	//Insert the request details done by the manager in the database.
	public final String REQUEST_QUERY="INSERT INTO Asset_Allocation values(sq_allocationid.NEXTVAL,?,?,SYSDATE,null,'Pending')";
	
	//used to validate the entered AssetId by the manager
	public final String ASSET_ID_QUERY="SELECT AssetId FROM Asset WHERE AssetId=?";
	
	//used to validate the entered EmployeeId by the manager
	public final String EMPLOYEE_ID_QUERY="SELECT Empno FROM Employee WHERE Empno=?";
	
	//to select the manager of the employee to whom the request is raised 
	public final String GET_MANAGER_OF_EMPLOYEE_QUERY="SELECT mgr FROM Employee WHERE Empno=?";
	
	//To select the current value of the AllocationId to display to the user
	public final String ALLOCATION_ID_VALUE="SELECT sq_allocationid.CURRVAL FROM DUAL";
	
	//To select the Status of the RequisitionId/AllocationId 
 	public final String STATUS_QUERY="SELECT Asset_status FROM Asset_Allocation WHERE AllocationId=?";
	
 	//used to validate the entered RequisitionId/AllocationId by the manager
	public final String REQUSITION_ID_QUERY="SELECT AllocationId FROM Asset_Allocation WHERE AllocationId=?";
	
	
	//Queries used by Admin method
	//To insert the asset details entered by the admin in the database
	public final String INSERT_DETAILS="INSERT INTO Asset VALUES(seq_assetId.NEXTVAL,?,?,?,?)";
	
	//To get the asset details of the Asssets in the Asset Table 
	public final String GET_ASSET_DETAILS="SELECT AssetId,AssetName,AssetDes,Quantity,Status FROM Asset ORDER BY AssetId";
	
	//To update the Asset Name in the asset table
	public final String UPDATE_ASSET_NAME_DETAILS="UPDATE Asset SET AssetName=? WHERE AssetId=?";
	
	//To update the Asset Description in the asset table
	public final String UPDATE_ASSET_DESCRIPTION_DETAILS="UPDATE Asset SET AssetDes=? WHERE AssetId=?";
	
	//To update the Asset Quantity in the asset table
	public final String UPDATE_ASSET_QUANTITY_DETAILS="UPDATE Asset SET Quantity=? WHERE AssetId=?";
	
	//To update the Asset Status in the asset table
	public final String UPDATE_ASSET_STATUS_DETAILS="UPDATE Asset SET Status=? WHERE AssetId=?";
	
	//To Select the AssetId of the Asset which matches both the condition given in the query
	public final String CHECK_ASSET_STATUS="select a.assetid from ASSET a,Asset_Allocation aa where aa.AllocationId=? and a.status='Available' and a.assetid=aa.assetid";
	
	//used to validate the entered RequisitionId/AllocationId by the Admin
	public final String CHECK_ALLOCATION_ID="SELECT AllocationId FROM Asset_Allocation WHERE AllocationId=? ";
	
	//To update the allocation table when the request is approved successfully
	public final String APPROVE_REQ="UPDATE Asset_Allocation SET Asset_status='Approved', Release_date=SYSDATE+2 WHERE AllocationId=? and AssetId=? and Asset_status='Pending'";
	
	//To update the asset table about the reduction in quantity of the asset when a request is successfully approved
	public final String REDUCE_QUANTITY_ON_APPROVAL="UPDATE Asset SET Quantity=Quantity-1 WHERE AssetId=(Select AssetId FROM Asset_Allocation WHERE AllocationId=?)";
	
	//To change the status the asset when the quantity reaches 0.
	public final String CHANGE_STATUS="UPDATE Asset SET Status='Not Available' WHERE Quantity=0";
	
	//To update the Asset_Allocation table with asset_Status when a request the rejected
	public final String REJECT_REQ="UPDATE Asset_Allocation SET Asset_status='Rejected' WHERE AllocationId=?";
	
	//To display the unapproved/rejected request details
	public final String DISPLAY_UNAPPROVED_DETAILS="SELECT AllocationId,AssetId,Empno,Allocation_date,Release_date FROM Asset_Allocation WHERE Asset_status='Pending' ORDER BY AllocationId";
	
	//To display the Allocated request details
	public final String DISPLAY_ALLOCATED_DETAILS="SELECT AllocationId,AssetId,Empno,Allocation_date,Release_date FROM Asset_Allocation WHERE Asset_status='Approved' ORDER BY AllocationId";
	
	//To display the Unallocated request details
	public final String DISPLAY_UNALLOCATED_DETAILS="SELECT AllocationId,AssetId,Empno,Allocation_date,Release_date FROM Asset_Allocation WHERE Asset_status='Rejected' ORDER BY AllocationId";
	
}