/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The UserMasterBeanTest contains the test cases for the methods in the  
 * UserMasterBean class which are the methods of getters and setters */

package com.capgemini.ams.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.ams.bean.UserMasterBean;

public class UserMasterBeanTest {

	UserMasterBean userMaster=new UserMasterBean();
	/************************************
	 * Test case for setUserId()
	 * 
	 ************************************/
	@Test
	public void testSetUserId() {
		userMaster.setUserId("180010");
		assertEquals("180010",userMaster.getUserId());
	}

	/************************************
	 * Test case for setUserName()
	 * 
	 ************************************/
	@Test
	public void testSetUserName() {
		userMaster.setUserName("Admin");
		assertEquals("Admin",userMaster.getUserName());
	}

	/************************************
	 * Test case for setPassword()
	 * 
	 ************************************/
	@Test
	public void testSetPassword() {
		userMaster.setPassword("admin");;
		assertEquals("admin",userMaster.getPassword());
	}

	/************************************
	 * Test case for setUserType()
	 * 
	 ************************************/
	@Test
	public void testSetUserType() {
		userMaster.setUserType("Admin");
		assertEquals("Admin",userMaster.getUserType());
	}

}
