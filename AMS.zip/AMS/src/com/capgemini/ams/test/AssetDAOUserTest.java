/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The AssetDAOUserTest contains the test cases for the methods in the  
 * AssetDAOUser which are the methods of operations that are carried out by the user */

package com.capgemini.ams.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.dao.AssetDAOUser;
import com.capgemini.ams.dao.IAssetDAOUser;
import com.capgemini.ams.exception.AMSException;

public class AssetDAOUserTest {

	IAssetDAOUser serviceUser=null;
	
	/************************************
	 * Test case for authenticateUser()
	 * 
	 ************************************/
	@Test
	public void testAuthenticateUser() throws AMSException {
		
		UserMasterBean userMaster=new UserMasterBean("180010","biswa9");
		serviceUser=new AssetDAOUser();
		assertEquals(1,serviceUser.authenticateUser(userMaster));
	}

	/************************************
	 * Test case for raiseRequest()
	 * 
	 ************************************/
	@Test
	public void testRaiseRequest() throws AMSException {

		AssetAllocationBean assetAllocation=new AssetAllocationBean(3001, 10025);
		serviceUser=new AssetDAOUser();
		assertEquals(6104, serviceUser.raiseRequest(assetAllocation));
	}

	/************************************
	 * Test case for checkAssetId()
	 * 
	 ************************************/
	@Test
	public void testCheckAssetId() throws AMSException {
		
		int assetId=2000;
		serviceUser=new AssetDAOUser();
		assertEquals(1, serviceUser.checkAssetId(assetId));
	}

	/************************************
	 * Test case for checkEmployeeId()
	 * 
	 ************************************/
	@Test
	public void testCheckEmployeeId() throws AMSException {

		int employeeId=10025;
		serviceUser=new AssetDAOUser();
		assertEquals(1, serviceUser.checkEmployeeId(employeeId));
	}

	/************************************
	 * Test case for checkEmployee()
	 * 
	 ************************************/
	@Test
	public void testCheckEmployee() throws AMSException {
		
		String userId="180010";
		int employeeId=10025;
		serviceUser=new AssetDAOUser();
		assertEquals(1, serviceUser.checkEmployee(userId, employeeId));
	}

	/************************************
	 * Test case for viewStatus()
	 * 
	 ************************************/
	@Test
	public void testViewStatusOfRequisitionId() throws AMSException {
		
		AssetAllocationBean assetAllocation= new AssetAllocationBean();
		assetAllocation.setAllocationId(6000);
		serviceUser=new AssetDAOUser();
		assertEquals("Approved", serviceUser.viewStatusOfRequisitionId(assetAllocation));
	}

	/************************************
	 * Test case for checkRequisitionId()
	 * 
	 ************************************/
	@Test
	public void testCheckRequisitionId() throws AMSException {
		
		int requisitionId=6054;
		serviceUser=new AssetDAOUser();
		assertEquals(1, serviceUser.checkRequisitionId(requisitionId));
	}

}
