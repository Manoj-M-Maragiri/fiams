/***********************************Author Name:Manoj M Maragiri*********Emp Id : 155246******************************************/
/*The AssetServiceUser contains the implementation of the methods that are being used by the user
 *and performs the required operations that are needed by the user. It also contains the 
 *validations of the input taken from the user.
*/
package com.capgemini.ams.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.dao.AssetDAOUser;
import com.capgemini.ams.dao.IAssetDAOUser;
import com.capgemini.ams.exception.AMSException;

public class AssetServiceUser implements IAssetServiceUser{
	
	IAssetDAOUser assetdaoUser=null;
	
	//method to authenticate the login credentials
	public int authenticateUser(UserMasterBean userMaster) throws AMSException {
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.authenticateUser(userMaster);
		
	}
	
	//method to display the assetdetails to the user using an arraylist
	public ArrayList<AssetDetailsBean> displayAssetDetails() throws AMSException {
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.displayAssetDetails();
	}
	
	//method to raise a request by a manager/user which takes an object as an argument 
	public int raiseRequest(AssetAllocationBean assetAllocation) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.raiseRequest(assetAllocation);
	}
	
	//method to check whether the assetId entered is present in the table or not, which takes assetid as an argument
	public int checkAssetId(int assetId) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.checkAssetId(assetId);
		
	}
	
	//method to check whether the employeeId is present in the table or not,which takes employeeId as an argument
	public int checkEmployeeId(int employeeId) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.checkEmployeeId(employeeId);
		
	}
	
	//method to check whether the employee is under the logined manager in the table or not,which takes userId and employeeId as an argument
	public int checkEmployee(String userId,int employeeId) throws AMSException {
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.checkEmployee(userId,employeeId);
		
	}


	//viewStatusOfRequisitionId is a method to get the current value of the requisitionId which takes an object as an argument 
	public String viewStatusOfRequisitionId(AssetAllocationBean assetAllocation) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.viewStatusOfRequisitionId(assetAllocation);
		
	}


	//checkRequisitionId is a method to check whether requisitionid is present in the table or not, which takes requisitionId as an parameter
	public int checkRequisitionId(int requisitionId) throws AMSException {
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.checkRequisitionId(requisitionId);
		
	}
	
	
	//method to validate userId
	public boolean isValidUserId(String userId) {
		
		Pattern pattern = Pattern.compile("[0-9]{6}");
		Matcher matcher = pattern.matcher(userId);
		return matcher.matches();

	} 
	
	//method to validate assetId
	public boolean isValidAssetId(String dummyAssetId) {
		
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(dummyAssetId);
		return matcher.matches();

	}


	//method to validate employeeId
	public boolean isValidEmployeeId(String dummyEmployeeId) {
		
		Pattern pattern = Pattern.compile("[0-9]{5}");
		Matcher matcher = pattern.matcher(dummyEmployeeId);
		return matcher.matches();
		
	} 
	
	
	//method to validate requisition Id
	public boolean isValidRequisitionId(String dummyRequisitionId) {
		
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(dummyRequisitionId);
		return matcher.matches();
		
	}


	//method to validate quantity
	public boolean isValidQuantity(String dummyQuantityValue) {
		
		Pattern pattern = Pattern.compile("[0-9]{1,9}");
		Matcher matcher = pattern.matcher(dummyQuantityValue);
		
		return matcher.matches();
		
	}


	//method to validate option
	public boolean isValidOption(String option) {
		
		Pattern pattern = Pattern.compile("[0-9]");
		Matcher matcher = pattern.matcher(option);
		return matcher.matches();
		
	}


	//method to validate password
	public boolean isValidPassword(String password) {

		Pattern pattern = Pattern.compile("[A-Za-z0-9&!@#$_]{5,50}");
		Matcher matcher = pattern.matcher(password);
		return matcher.matches();

	} 
}
